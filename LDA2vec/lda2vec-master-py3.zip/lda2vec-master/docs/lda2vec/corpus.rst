lda2vec.corpus module
---------------------

.. automodule:: lda2vec.corpus
    :members:
    :undoc-members:
    :show-inheritance:
