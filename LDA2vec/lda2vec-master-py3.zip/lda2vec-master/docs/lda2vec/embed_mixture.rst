lda2vec.embed_mixture module
----------------------------

.. automodule:: lda2vec.embed_mixture
    :members:
    :undoc-members:
    :show-inheritance:
